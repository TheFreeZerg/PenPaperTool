package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class NewPlaceW {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Create the application.
	 */
	public NewPlaceW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("New Place");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(10, 11, 124, 14);
		frame.getContentPane().add(lblName);
		
		textField = new JTextField();
		textField.setBounds(144, 8, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblIcon = new JLabel("Icon");
		lblIcon.setBounds(10, 43, 77, 14);
		frame.getContentPane().add(lblIcon);
		
		JButton btnBrose = new JButton("brose");
		btnBrose.setBounds(144, 39, 89, 23);
		frame.getContentPane().add(btnBrose);
		
		JLabel lblNewLabel = new JLabel("Image Label");
		lblNewLabel.setBounds(280, 43, 94, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblDescription = new JLabel("Description");
		lblDescription.setBounds(10, 68, 124, 28);
		frame.getContentPane().add(lblDescription);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 106, 414, 110);
		frame.getContentPane().add(scrollPane);
		
		JTextArea txtrSomeDetailedDescription = new JTextArea();
		txtrSomeDetailedDescription.setText("Some Detailed Description");
		scrollPane.setViewportView(txtrSomeDetailedDescription);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnClose.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnApply = new JButton("apply");
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnApply.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnApply);
		
		frame.setVisible(true);
	}
}
