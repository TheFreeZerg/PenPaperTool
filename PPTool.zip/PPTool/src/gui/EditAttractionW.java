package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EditAttractionW {

	private JFrame frmEditAttraction;
	private JTextField textField;

	/**
	 * Create the application.
	 */
	public EditAttractionW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmEditAttraction = new JFrame();
		frmEditAttraction.setTitle("Edit Attraction");
		frmEditAttraction.setBounds(100, 100, 450, 412);
		frmEditAttraction.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmEditAttraction.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(137, 11, 86, 20);
		frmEditAttraction.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("new name");
		lblNewLabel.setBounds(10, 11, 86, 20);
		frmEditAttraction.getContentPane().add(lblNewLabel);
		
		JLabel lblNewIcon = new JLabel("new icon");
		lblNewIcon.setBounds(10, 42, 86, 23);
		frmEditAttraction.getContentPane().add(lblNewIcon);
		
		JButton btnBrowse = new JButton("browse");
		btnBrowse.setBounds(134, 41, 89, 23);
		frmEditAttraction.getContentPane().add(btnBrowse);
		
		JLabel lblIcon = new JLabel("icon");
		lblIcon.setBounds(259, 42, 86, 23);
		frmEditAttraction.getContentPane().add(lblIcon);
		
		JLabel lblDescription = new JLabel("description");
		lblDescription.setBounds(10, 76, 86, 20);
		frmEditAttraction.getContentPane().add(lblDescription);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 107, 414, 55);
		frmEditAttraction.getContentPane().add(scrollPane);
		
		JTextArea txtrDescription = new JTextArea();
		txtrDescription.setText("description");
		scrollPane.setViewportView(txtrDescription);
		
		JLabel lblSubattractions = new JLabel("sub-attractions");
		lblSubattractions.setBounds(10, 173, 86, 20);
		frmEditAttraction.getContentPane().add(lblSubattractions);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 204, 414, 61);
		frmEditAttraction.getContentPane().add(scrollPane_1);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"sub-attraction 1", "sub-attraction 2", "sub-attraction 3"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane_1.setViewportView(list);
		
		JButton btnNew = new JButton("new");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new NewAttractionW();
			}
		});
		btnNew.setBounds(10, 270, 89, 23);
		frmEditAttraction.getContentPane().add(btnNew);
		
		JButton btnEdit = new JButton("edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditAttractionW();
			}
		});
		btnEdit.setBounds(109, 270, 89, 23);
		frmEditAttraction.getContentPane().add(btnEdit);
		
		JButton btnDel = new JButton("del");
		btnDel.setBounds(307, 270, 89, 23);
		frmEditAttraction.getContentPane().add(btnDel);
		
		JButton btnShow = new JButton("show");
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ShowAttractionW();
			}
		});
		btnShow.setBounds(208, 270, 89, 23);
		frmEditAttraction.getContentPane().add(btnShow);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmEditAttraction.dispose();
			}
		});
		btnClose.setBounds(10, 343, 89, 23);
		frmEditAttraction.getContentPane().add(btnClose);
		
		JButton btnApply = new JButton("apply");
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmEditAttraction.dispose();
			}
		});
		btnApply.setBounds(307, 343, 89, 23);
		frmEditAttraction.getContentPane().add(btnApply);
		
		frmEditAttraction.setVisible(true);
	}
}
