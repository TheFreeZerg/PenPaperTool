package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JButton;

public class NoteW {

	private JFrame frmNotes;

	/**
	 * Create the application.
	 */
	public NoteW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmNotes = new JFrame();
		frmNotes.setTitle("Notes");
		frmNotes.setBounds(100, 100, 450, 234);
		frmNotes.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmNotes.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 304, 173);
		frmNotes.getContentPane().add(scrollPane);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"note 1", "note 2", "note 3", "new note"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane.setViewportView(list);
		
		JButton btnShow = new JButton("open");
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ShowNoteW();
			}
		});
		btnShow.setBounds(324, 9, 89, 23);
		frmNotes.getContentPane().add(btnShow);
		
		JButton btnDelete = new JButton("delete");
		btnDelete.setBounds(324, 43, 89, 23);
		frmNotes.getContentPane().add(btnDelete);
		
		JButton btnNew = new JButton("new");
		btnNew.setBounds(324, 77, 89, 23);
		frmNotes.getContentPane().add(btnNew);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmNotes.dispose();
			}
		});
		btnClose.setBounds(335, 161, 89, 23);
		frmNotes.getContentPane().add(btnClose);
		
		frmNotes.setVisible(true);
	}
}
