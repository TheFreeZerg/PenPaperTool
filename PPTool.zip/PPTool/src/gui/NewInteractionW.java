package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class NewInteractionW {

	private JFrame frmNewInteraction;
	private JTextField textField;

	/**
	 * Create the application.
	 */
	public NewInteractionW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmNewInteraction = new JFrame();
		frmNewInteraction.setTitle("New Interaction");
		frmNewInteraction.setBounds(100, 100, 450, 428);
		frmNewInteraction.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmNewInteraction.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(160, 11, 86, 20);
		frmNewInteraction.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(10, 14, 86, 20);
		frmNewInteraction.getContentPane().add(lblNewLabel);
		
		JLabel lblDescription = new JLabel("Description");
		lblDescription.setBounds(10, 45, 86, 20);
		frmNewInteraction.getContentPane().add(lblDescription);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 76, 414, 81);
		frmNewInteraction.getContentPane().add(scrollPane);
		
		JTextArea txtrDescription = new JTextArea();
		txtrDescription.setText("Description");
		scrollPane.setViewportView(txtrDescription);
		
		JLabel lblInvolved = new JLabel("Involved");
		lblInvolved.setBounds(10, 168, 86, 20);
		frmNewInteraction.getContentPane().add(lblInvolved);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 199, 414, 81);
		frmNewInteraction.getContentPane().add(scrollPane_1);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"involved 1", "involved 2", "involved 3"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane_1.setViewportView(list);
		
		JButton btnAdd = new JButton("add");
		btnAdd.setBounds(10, 291, 89, 23);
		frmNewInteraction.getContentPane().add(btnAdd);
		
		JButton btnRemove = new JButton("remove");
		btnRemove.setBounds(109, 291, 89, 23);
		frmNewInteraction.getContentPane().add(btnRemove);
		
		JLabel lblCondition = new JLabel("Condition");
		lblCondition.setBounds(10, 325, 86, 20);
		frmNewInteraction.getContentPane().add(lblCondition);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"always", "Forest", "City"}));
		comboBox.setBounds(109, 325, 89, 22);
		frmNewInteraction.getContentPane().add(comboBox);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmNewInteraction.dispose();
			}
		});
		btnClose.setBounds(10, 356, 89, 23);
		frmNewInteraction.getContentPane().add(btnClose);
		
		JButton btnApply = new JButton("apply");
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmNewInteraction.dispose();
			}
		});
		btnApply.setBounds(335, 356, 89, 23);
		frmNewInteraction.getContentPane().add(btnApply);
		
		frmNewInteraction.setVisible(true);
	}
}
