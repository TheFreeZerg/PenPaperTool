package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JButton;

public class ShowInteractionW {

	private JFrame frmInteraction;

	/**
	 * Create the application.
	 */
	public ShowInteractionW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmInteraction = new JFrame();
		frmInteraction.setTitle("Interaction");
		frmInteraction.setBounds(100, 100, 450, 392);
		frmInteraction.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmInteraction.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("name");
		lblName.setBounds(10, 11, 115, 23);
		frmInteraction.getContentPane().add(lblName);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 45, 414, 95);
		frmInteraction.getContentPane().add(scrollPane);
		
		JTextArea txtrDescription = new JTextArea();
		txtrDescription.setEditable(false);
		txtrDescription.setText("Description");
		scrollPane.setViewportView(txtrDescription);
		
		JLabel lblInvolved = new JLabel("Involved");
		lblInvolved.setBounds(10, 151, 115, 23);
		frmInteraction.getContentPane().add(lblInvolved);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 185, 414, 95);
		frmInteraction.getContentPane().add(scrollPane_1);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"involved 1", "involved 2", "involved 3"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane_1.setViewportView(list);
		
		JLabel lblCondition = new JLabel("Condition");
		lblCondition.setBounds(10, 291, 115, 23);
		frmInteraction.getContentPane().add(lblCondition);
		
		JLabel lblAlways = new JLabel("Always");
		lblAlways.setBounds(135, 291, 115, 23);
		frmInteraction.getContentPane().add(lblAlways);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmInteraction.dispose();
			}
		});
		btnClose.setBounds(10, 325, 89, 23);
		frmInteraction.getContentPane().add(btnClose);
		
		JButton btnApply = new JButton("apply");
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmInteraction.dispose();
			}
		});
		btnApply.setBounds(335, 325, 89, 23);
		frmInteraction.getContentPane().add(btnApply);
		
		frmInteraction.setVisible(true);
	}
}
