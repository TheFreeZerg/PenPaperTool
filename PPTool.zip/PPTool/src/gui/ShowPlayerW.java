package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class ShowPlayerW {

	private JFrame frame;

	/**
	 * Create the application.
	 */
	public ShowPlayerW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Player");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblDetailsOverDetails = new JLabel("Details over Details");
		lblDetailsOverDetails.setBounds(10, 11, 262, 32);
		frame.getContentPane().add(lblDetailsOverDetails);
		
		frame.setVisible(true);
	}

}
