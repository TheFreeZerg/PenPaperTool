package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.AbstractListModel;

public class PlayerW {

	private JFrame frmPlayers;

	/**
	 * Create the application.
	 */
	public PlayerW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPlayers = new JFrame();
		frmPlayers.setTitle("Players");
		frmPlayers.setBounds(100, 100, 450, 300);
		frmPlayers.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmPlayers.getContentPane().setLayout(null);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"Michael", "Alex", "Andreas", "Olli"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		list.setBounds(10, 11, 288, 170);
		frmPlayers.getContentPane().add(list);
		
		JButton btnEdit = new JButton("edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditPlayerW();
			}
		});
		btnEdit.setBounds(308, 11, 89, 23);
		frmPlayers.getContentPane().add(btnEdit);
		
		JButton btnNew = new JButton("new");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new NewPlayerW();
			}
		});
		btnNew.setBounds(308, 45, 89, 23);
		frmPlayers.getContentPane().add(btnNew);
		
		JButton btnDelete = new JButton("delete");
		btnDelete.setBounds(308, 79, 89, 23);
		frmPlayers.getContentPane().add(btnDelete);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmPlayers.dispose();
			}
		});
		btnClose.setBounds(10, 205, 89, 23);
		frmPlayers.getContentPane().add(btnClose);
		
		JButton btnOpenAll = new JButton("open all");
		btnOpenAll.setBounds(209, 205, 89, 23);
		frmPlayers.getContentPane().add(btnOpenAll);
		
		JButton btnShow = new JButton("show");
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ShowPlayerW();
			}
		});
		btnShow.setBounds(308, 113, 89, 23);
		frmPlayers.getContentPane().add(btnShow);
		
		frmPlayers.setVisible(true);
	}
}
