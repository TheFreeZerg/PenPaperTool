package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JButton;

public class ShowPlaceW {

	private JFrame frame;

	/**
	 * Create the application.
	 */
	public ShowPlaceW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Place");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(10, 11, 134, 34);
		frame.getContentPane().add(lblName);
		
		JLabel lblIcon = new JLabel("Icon");
		lblIcon.setBounds(154, 11, 270, 34);
		frame.getContentPane().add(lblIcon);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 56, 414, 65);
		frame.getContentPane().add(scrollPane);
		
		JTextArea txtrDescription = new JTextArea();
		txtrDescription.setText("Description");
		scrollPane.setViewportView(txtrDescription);
		
		JLabel lblAttractions = new JLabel("Attractions");
		lblAttractions.setBounds(10, 132, 117, 25);
		frame.getContentPane().add(lblAttractions);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 168, 414, 34);
		frame.getContentPane().add(scrollPane_1);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"Attraction 1", "Attraction 2"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane_1.setViewportView(list);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnClose.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnEdit = new JButton("edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditPlaceW();
			}
		});
		btnEdit.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnEdit);
		
		frame.setVisible(true);
	}
}
