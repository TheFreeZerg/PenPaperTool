package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class EditPlayerW {

	private JFrame frmPlayerName;

	/**
	 * Create the application.
	 */
	public EditPlayerW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPlayerName = new JFrame();
		frmPlayerName.setTitle("Edit Player");
		frmPlayerName.setBounds(100, 100, 450, 300);
		frmPlayerName.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmPlayerName.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("like show Player, but with the possibility of applying changes");
		lblNewLabel.setBounds(29, 36, 360, 66);
		frmPlayerName.getContentPane().add(lblNewLabel);
		
		frmPlayerName.setVisible(true);
	}
}
