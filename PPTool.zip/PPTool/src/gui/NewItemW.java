package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class NewItemW {

	private JFrame frame;
	private JTextField txtOldName;

	/**
	 * Create the application.
	 */
	public NewItemW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("New Item");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewName = new JLabel("Name");
		lblNewName.setBounds(10, 11, 90, 14);
		frame.getContentPane().add(lblNewName);
		
		JLabel lblChangeType = new JLabel("Type");
		lblChangeType.setBounds(10, 36, 90, 14);
		frame.getContentPane().add(lblChangeType);
		
		JLabel lblVariablen = new JLabel("Variablen");
		lblVariablen.setBounds(10, 61, 90, 14);
		frame.getContentPane().add(lblVariablen);
		
		txtOldName = new JTextField();
		txtOldName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtOldName.setText("");
			}
		});
		txtOldName.setBounds(161, 8, 86, 20);
		frame.getContentPane().add(txtOldName);
		txtOldName.setColumns(10);
		
		JLabel label = new JLabel("...");
		label.setBounds(161, 61, 46, 14);
		frame.getContentPane().add(label);
		
		JButton btnApply = new JButton("apply");
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnApply.setBounds(158, 227, 89, 23);
		frame.getContentPane().add(btnApply);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnClose.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Weapon", "Armor", "Miscellaneous"}));
		comboBox.setBounds(161, 32, 86, 22);
		frame.getContentPane().add(comboBox);
		
		frame.setVisible(true);
	}
}
