package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ItemW {

	private JFrame frmItems;
	private JTable table;

	/**
	 * Create the application.
	 */
	public ItemW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmItems = new JFrame();
		frmItems.setTitle("Items");
		frmItems.setBounds(100, 100, 450, 300);
		frmItems.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmItems.getContentPane().setLayout(null);
		
		JButton btnEdit = new JButton("edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditItemW();
			}
		});
		btnEdit.setBounds(349, 11, 75, 23);
		frmItems.getContentPane().add(btnEdit);
		
		JButton btnDel = new JButton("del");
		btnDel.setBounds(349, 45, 75, 23);
		frmItems.getContentPane().add(btnDel);
		
		JButton btnShow = new JButton("show");
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ShowItemW();
			}
		});
		btnShow.setBounds(349, 79, 75, 23);
		frmItems.getContentPane().add(btnShow);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmItems.dispose();
			}
		});
		btnClose.setBounds(10, 227, 89, 23);
		frmItems.getContentPane().add(btnClose);
		
		JButton btnNewItem = new JButton("new Item");
		btnNewItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new NewItemW();
			}
		});
		btnNewItem.setBounds(256, 227, 89, 23);
		frmItems.getContentPane().add(btnNewItem);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 329, 205);
		frmItems.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"Sword", "w"},
				{"Helmet", "a"},
				{"Torch", "m"},
			},
			new String[] {
				"Name", "Type"
			}
		));
		scrollPane.setViewportView(table);
		
		frmItems.setVisible(true);
	}
}
