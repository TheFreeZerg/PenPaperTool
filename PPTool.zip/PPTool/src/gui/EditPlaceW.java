package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.AbstractListModel;

public class EditPlaceW {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Create the application.
	 */
	public EditPlaceW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Edit Place");
		frame.setBounds(100, 100, 455, 365);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewName = new JLabel("new name");
		lblNewName.setBounds(10, 11, 91, 20);
		frame.getContentPane().add(lblNewName);
		
		textField = new JTextField();
		textField.setBounds(172, 11, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewIcon = new JLabel("new icon");
		lblNewIcon.setBounds(10, 42, 91, 23);
		frame.getContentPane().add(lblNewIcon);
		
		JButton btnNewButton = new JButton("browse");
		btnNewButton.setBounds(172, 42, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("icon");
		lblNewLabel.setBounds(305, 42, 91, 23);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblDescription = new JLabel("Description");
		lblDescription.setBounds(10, 76, 91, 23);
		frame.getContentPane().add(lblDescription);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 110, 414, 46);
		frame.getContentPane().add(scrollPane);
		
		JTextArea txtrDescripe = new JTextArea();
		txtrDescripe.setText("Descripe");
		scrollPane.setViewportView(txtrDescripe);
		
		JLabel lblAttractions = new JLabel("Attractions");
		lblAttractions.setBounds(10, 167, 91, 23);
		frame.getContentPane().add(lblAttractions);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 201, 414, 49);
		frame.getContentPane().add(scrollPane_1);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"Attraction 1", "Attraction 2"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane_1.setViewportView(list);
		
		JButton btnEdit = new JButton("edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditAttractionW();
			}
		});
		btnEdit.setBounds(10, 261, 89, 23);
		frame.getContentPane().add(btnEdit);
		
		JButton btnNewButton_2 = new JButton("delete");
		btnNewButton_2.setBounds(109, 261, 89, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNew = new JButton("new");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new NewAttractionW();
			}
		});
		btnNew.setBounds(208, 261, 89, 23);
		frame.getContentPane().add(btnNew);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnClose.setBounds(10, 295, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnApply = new JButton("apply");
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnApply.setBounds(335, 295, 89, 23);
		frame.getContentPane().add(btnApply);
		
		frame.setVisible(true);
	}
}
