package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.FlowLayout;
import javax.swing.JPanel;

public class WelcomeW {

	private JFrame frmWelcome;

	/**
	 * Create the application.
	 */
	public WelcomeW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmWelcome = new JFrame();
		frmWelcome.setTitle("Welcome");
		frmWelcome.setBounds(100, 100, 131, 177);
		frmWelcome.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmWelcome.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 99, 33);
		frmWelcome.getContentPane().add(panel);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton btnNewButton = new JButton("new");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new NewProfileW();
				frmWelcome.dispose();
			}
		});
		panel.add(btnNewButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 55, 99, 33);
		frmWelcome.getContentPane().add(panel_1);
		
		JButton button = new JButton("load");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ProfileW();
				frmWelcome.dispose();
			}
		});
		panel_1.add(button);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 99, 99, 33);
		frmWelcome.getContentPane().add(panel_2);
		
		JButton button_1 = new JButton("erase");
		panel_2.add(button_1);
		
		frmWelcome.setVisible(true);
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new WelcomeW();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
