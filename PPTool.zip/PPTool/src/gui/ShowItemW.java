package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

public class ShowItemW {

	private JFrame frame;
	private JTable table;

	/**
	 * Create the application.
	 */
	public ShowItemW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Item");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 414, 205);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setEnabled(false);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"Name", "Phantom Dancer"},
				{"Type", "Weapon"},
				{"Multiplier", "1.3"},
				{"Value", "3000g"},
				{"Buff", "Speed(1.5)"},
			},
			new String[] {
				"Variable", "Value"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnClose.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnEdit = new JButton("edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditItemW();
			}
		});
		btnEdit.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnEdit);
		
		frame.setVisible(true);
	}
}
