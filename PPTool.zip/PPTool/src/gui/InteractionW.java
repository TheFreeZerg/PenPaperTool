package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class InteractionW {

	private JFrame frame;
	private JTable table;

	/**
	 * Create the application.
	 */
	public InteractionW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Interactions");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 315, 205);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setEnabled(false);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"Hungry","always"},
				{"Wolves","Forest"},
				{"Guards","City"},
			},
			new String[] {
				"Name", "Condition"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnClose.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnNew = new JButton("new");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new NewInteractionW();
			}
		});
		btnNew.setBounds(335, 11, 89, 23);
		frame.getContentPane().add(btnNew);
		
		JButton btnOpen = new JButton("open");
		btnOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ShowInteractionW();
			}
		});
		btnOpen.setBounds(335, 45, 89, 23);
		frame.getContentPane().add(btnOpen);
		
		JButton btnEdit = new JButton("edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditInteractionW();
			}
		});
		btnEdit.setBounds(335, 79, 89, 23);
		frame.getContentPane().add(btnEdit);
		
		JButton btnDelete = new JButton("delete");
		btnDelete.setBounds(335, 113, 89, 23);
		frame.getContentPane().add(btnDelete);
		
		frame.setVisible(true);
	}
}
