package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class NewPlayerW {

	private JFrame frmNewPlayer;
	private JTextField textField;

	/**
	 * Create the application.
	 */
	public NewPlayerW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmNewPlayer = new JFrame();
		frmNewPlayer.setTitle("New Player");
		frmNewPlayer.setBounds(100, 100, 450, 300);
		frmNewPlayer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmNewPlayer.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(10, 11, 46, 14);
		frmNewPlayer.getContentPane().add(lblName);
		
		textField = new JTextField();
		textField.setBounds(71, 8, 86, 20);
		frmNewPlayer.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblStats = new JLabel("Stats\t\t...");
		lblStats.setBounds(10, 36, 147, 14);
		frmNewPlayer.getContentPane().add(lblStats);
		
		JLabel lblSkills = new JLabel("Skills...");
		lblSkills.setBounds(10, 62, 147, 14);
		frmNewPlayer.getContentPane().add(lblSkills);
		
		JLabel lblLore = new JLabel("Lore...");
		lblLore.setBounds(10, 87, 147, 14);
		frmNewPlayer.getContentPane().add(lblLore);
		
		JLabel lblDetails = new JLabel("Details...");
		lblDetails.setBounds(10, 112, 147, 14);
		frmNewPlayer.getContentPane().add(lblDetails);
		
		JLabel lblWeapons = new JLabel("Weapons...");
		lblWeapons.setBounds(10, 137, 147, 14);
		frmNewPlayer.getContentPane().add(lblWeapons);
		
		frmNewPlayer.setVisible(true);
	}
}
