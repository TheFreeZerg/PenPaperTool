package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class NewAttractionW {

	private JFrame frmNewAttraction;
	private JTextField textField;

	/**
	 * Create the application.
	 */
	public NewAttractionW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmNewAttraction = new JFrame();
		frmNewAttraction.setTitle("New Attraction");
		frmNewAttraction.setBounds(100, 100, 450, 238);
		frmNewAttraction.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmNewAttraction.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(137, 11, 86, 20);
		frmNewAttraction.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("new name");
		lblNewLabel.setBounds(10, 11, 86, 20);
		frmNewAttraction.getContentPane().add(lblNewLabel);
		
		JLabel lblNewIcon = new JLabel("new icon");
		lblNewIcon.setBounds(10, 42, 86, 23);
		frmNewAttraction.getContentPane().add(lblNewIcon);
		
		JButton btnBrowse = new JButton("browse");
		btnBrowse.setBounds(134, 41, 89, 23);
		frmNewAttraction.getContentPane().add(btnBrowse);
		
		JLabel lblIcon = new JLabel("icon");
		lblIcon.setBounds(259, 42, 86, 23);
		frmNewAttraction.getContentPane().add(lblIcon);
		
		JLabel lblDescription = new JLabel("description");
		lblDescription.setBounds(10, 76, 86, 20);
		frmNewAttraction.getContentPane().add(lblDescription);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 107, 414, 55);
		frmNewAttraction.getContentPane().add(scrollPane);
		
		JTextArea txtrDescription = new JTextArea();
		txtrDescription.setText("description");
		scrollPane.setViewportView(txtrDescription);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmNewAttraction.dispose();
			}
		});
		btnClose.setBounds(10, 173, 89, 23);
		frmNewAttraction.getContentPane().add(btnClose);
		
		JButton btnApply = new JButton("apply");
		btnApply.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmNewAttraction.dispose();
			}
		});
		btnApply.setBounds(335, 173, 89, 23);
		frmNewAttraction.getContentPane().add(btnApply);
		
		frmNewAttraction.setVisible(true);
	}
}
