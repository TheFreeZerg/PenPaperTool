package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import java.awt.GridBagLayout;
import javax.swing.BoxLayout;

public class ProfileW {

	private JFrame frmProfile;

	/**
	 * Create the application.
	 */
	public ProfileW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmProfile = new JFrame();
		frmProfile.setTitle("Profile");
		frmProfile.setBounds(100, 100, 450, 300);
		frmProfile.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmProfile.getContentPane().setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(211, 0, 223, 261);
		frmProfile.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnInteraction = new JButton("Interaction");
		btnInteraction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new InteractionW();
			}
		});
		btnInteraction.setBounds(51, 52, 118, 23);
		panel_1.add(btnInteraction);
		
		JButton btnFight = new JButton("Fight");
		btnFight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FightW();
			}
		});
		btnFight.setBounds(51, 114, 85, 23);
		panel_1.add(btnFight);
		
		JButton btnNewButton = new JButton("Notes");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new NoteW();
			}
		});
		btnNewButton.setBounds(51, 183, 85, 23);
		panel_1.add(btnNewButton);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 201, 261);
		frmProfile.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnPlayer = new JButton("Player");
		btnPlayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PlayerW();
			}
		});
		btnPlayer.setBounds(61, 37, 91, 23);
		panel.add(btnPlayer);
		
		JButton btnPlaces = new JButton("Places");
		btnPlaces.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PlaceW();
			}
		});
		btnPlaces.setBounds(61, 87, 91, 23);
		panel.add(btnPlaces);
		
		JButton btnItems = new JButton("Items");
		btnItems.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ItemW();
			}
		});
		btnItems.setBounds(61, 141, 87, 23);
		panel.add(btnItems);
		
		JButton btnMap = new JButton("Map");
		btnMap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MapW();
			}
		});
		btnMap.setBounds(61, 194, 89, 23);
		panel.add(btnMap);

		frmProfile.setVisible(true);
	}
}
