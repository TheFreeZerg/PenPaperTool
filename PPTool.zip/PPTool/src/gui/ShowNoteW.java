package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;

public class ShowNoteW {

	private JFrame frmNote;

	/**
	 * Create the application.
	 */
	public ShowNoteW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmNote = new JFrame();
		frmNote.setTitle("Note");
		frmNote.setBounds(100, 100, 450, 300);
		frmNote.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmNote.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(10, 11, 113, 24);
		frmNote.getContentPane().add(lblName);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 51, 414, 164);
		frmNote.getContentPane().add(scrollPane);
		
		JTextArea txtrContent = new JTextArea();
		txtrContent.setText("Content");
		scrollPane.setViewportView(txtrContent);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmNote.dispose();
			}
		});
		btnClose.setBounds(10, 227, 89, 23);
		frmNote.getContentPane().add(btnClose);
		
		frmNote.setVisible(true);
	}
}
