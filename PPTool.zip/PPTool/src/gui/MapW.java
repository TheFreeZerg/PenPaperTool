package gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.AbstractListModel;
import javax.swing.JScrollPane;

public class MapW {

	private JFrame frame;

	/**
	 * Create the application.
	 */
	public MapW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Map");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel() {

			Point pointStart = null;
			Point pointEnd = null;

			{
				addMouseListener(new MouseAdapter() {
					@Override
					public void mousePressed(MouseEvent e) {
						pointStart = e.getPoint();
					}

					@Override
					public void mouseReleased(MouseEvent e) {
						pointStart = null;
					}
				});
				addMouseMotionListener(new MouseMotionAdapter() {
					@Override
					public void mouseMoved(MouseEvent e) {
						pointEnd = e.getPoint();
					}

					@Override
					public void mouseDragged(MouseEvent e) {
						pointEnd = e.getPoint();
						repaint();
					}
				});
			}

			public void paint(Graphics g) {
				super.paint(g);
				if (pointStart != null) {
					g.setColor(Color.RED);
					g.drawLine(pointStart.x, pointStart.y, pointEnd.x, pointEnd.y);
				}
			}
		};
		panel.setBounds(10, 11, 414, 239);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		frame.setVisible(true);
	}
}
