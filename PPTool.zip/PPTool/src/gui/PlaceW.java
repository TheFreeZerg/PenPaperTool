package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.AbstractListModel;

public class PlaceW {

	private JFrame frame;

	/**
	 * Create the application.
	 */
	public PlaceW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Places");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnClose.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnEdit = new JButton("edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditPlaceW();
			}
		});
		btnEdit.setBounds(335, 11, 89, 23);
		frame.getContentPane().add(btnEdit);
		
		JButton btnOpen = new JButton("show");
		btnOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ShowPlaceW();
			}
		});
		btnOpen.setBounds(335, 45, 89, 23);
		frame.getContentPane().add(btnOpen);
		
		JButton btnDelete = new JButton("delete");
		btnDelete.setBounds(335, 79, 89, 23);
		frame.getContentPane().add(btnDelete);
		
		JButton btnNew = new JButton("new");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new NewPlaceW();
			}
		});
		btnNew.setBounds(335, 113, 89, 23);
		frame.getContentPane().add(btnNew);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 315, 209);
		frame.getContentPane().add(scrollPane);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"Demacia", "Noxus", "Ionia", "Freljord", "Piltover", "Bilgewater", "Massya"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane.setViewportView(list);
		
		frame.setVisible(true);
	}

}
