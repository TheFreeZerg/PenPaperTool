package gui;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class NewProfileW {

	private JFrame frmNewProfile;
	private JTextField textField;

	/**
	 * Create the application.
	 */
	public NewProfileW() {
		initialize();
		frmNewProfile.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmNewProfile = new JFrame();
		frmNewProfile.setTitle("New Profile");
		frmNewProfile.setBounds(100, 100, 301, 136);
		frmNewProfile.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmNewProfile.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblName.setBounds(10, 11, 82, 24);
		frmNewProfile.getContentPane().add(lblName);
		
		JButton btnGo = new JButton("go");
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ProfileW();
				frmNewProfile.dispose();
			}
		});
		btnGo.setBounds(205, 14, 65, 23);
		frmNewProfile.getContentPane().add(btnGo);
		
		textField = new JTextField();
		textField.setBounds(87, 15, 86, 20);
		frmNewProfile.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnBack = new JButton("back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new WelcomeW();
				frmNewProfile.dispose();
			}
		});
		btnBack.setBounds(84, 63, 89, 23);
		frmNewProfile.getContentPane().add(btnBack);
		
		frmNewProfile.setVisible(true);
	}
}
