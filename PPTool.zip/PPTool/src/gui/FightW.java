package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class FightW {

	private JFrame frame;

	/**
	 * Create the application.
	 */
	public FightW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Fight");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblHilfestellungFrKmpfe = new JLabel("Hilfestellung fuer Kaempfe; aus strategischen gruenden noch undefiniert");
		lblHilfestellungFrKmpfe.setBounds(10, 65, 414, 124);
		frame.getContentPane().add(lblHilfestellungFrKmpfe);
		
		frame.setVisible(true);
	}

}
