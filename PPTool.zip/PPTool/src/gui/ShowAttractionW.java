package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JButton;

public class ShowAttractionW {

	private JFrame frmAttraction;

	/**
	 * Create the application.
	 */
	public ShowAttractionW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAttraction = new JFrame();
		frmAttraction.setTitle("Attraction");
		frmAttraction.setBounds(100, 100, 450, 300);
		frmAttraction.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAttraction.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(10, 11, 60, 20);
		frmAttraction.getContentPane().add(lblNewLabel);
		
		JLabel lblIcon = new JLabel("icon");
		lblIcon.setBounds(175, 14, 60, 20);
		frmAttraction.getContentPane().add(lblIcon);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 41, 414, 51);
		frmAttraction.getContentPane().add(scrollPane);
		
		JTextArea txtrDescription = new JTextArea();
		txtrDescription.setText("description");
		scrollPane.setViewportView(txtrDescription);
		
		JLabel lblSubattractions = new JLabel("Sub-Attractions");
		lblSubattractions.setBounds(10, 103, 117, 20);
		frmAttraction.getContentPane().add(lblSubattractions);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 134, 414, 82);
		frmAttraction.getContentPane().add(scrollPane_1);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"Sub-Attraction 1", "Sub-Attraction 2", "Sub-Attraction 3"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane_1.setViewportView(list);
		
		JButton btnClose = new JButton("close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmAttraction.dispose();
			}
		});
		btnClose.setBounds(10, 227, 89, 23);
		frmAttraction.getContentPane().add(btnClose);
		
		JButton btnEdit = new JButton("edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditAttractionW();
			}
		});
		btnEdit.setBounds(335, 227, 89, 23);
		frmAttraction.getContentPane().add(btnEdit);
		
		frmAttraction.setVisible(true);
	}
}
